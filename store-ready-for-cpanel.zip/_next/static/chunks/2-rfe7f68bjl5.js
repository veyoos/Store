(() => {
    "use strict";
    (globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["object" == typeof document ? document.currentScript : void 0, 28298, (e, t, r) => {
        e.i(47167), Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "useRouterBFCache", {
            enumerable: !0,
            get: function() {
                return l
            }
        });
        let n = e.r(71645);

        function l(e, t, r) {
            let [l, a] = (0, n.useState)(() => ({
                tree: e,
                renderTree: t,
                stateKey: r,
                next: null
            }));
            if (l.tree === e) return l;
            let u = {
                    tree: e,
                    renderTree: t,
                    stateKey: r,
                    next: null
                },
                o = 1,
                d = l,
                i = u;
            for (; null !== d && o < 3;) {
                if (d.stateKey === r) {
                    i.next = d.next;
                    break
                } {
                    o++;
                    let e = {
                        tree: d.tree,
                        renderTree: d.renderTree,
                        stateKey: d.stateKey,
                        next: null
                    };
                    i.next = e, i = e
                }
                d = d.next
            }
            return a(u), u
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 42903, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = {
            createClientParams: function() {
                return a.createRenderParamsFromClient
            },
            createClientSearchParams: function() {
                return u.createRenderSearchParamsFromClient
            }
        };
        for (var l in n) Object.defineProperty(r, l, {
            enumerable: !0,
            get: n[l]
        });
        let a = e.r(97689),
            u = e.r(66996);
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 47257, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "ClientPageRoot", {
            enumerable: !0,
            get: function() {
                return i
            }
        });
        let n = e.r(43476),
            l = e.r(8372),
            a = e.r(71645),
            u = e.r(33906),
            o = e.r(61994),
            d = e.r(42903);

        function i({
            Component: e,
            serverProvidedParams: t
        }) {
            let r, s;
            if (null !== t) r = t.searchParams, s = t.params;
            else {
                let e = (0, a.use)(l.LayoutRouterContext);
                s = null !== e ? e.parentParams : {}, r = (0, u.urlSearchParamsToParsedUrlQuery)((0, a.use)(o.SearchParamsContext))
            }
            let f = (0, d.createClientSearchParams)(r),
                c = (0, d.createClientParams)(s);
            return (0, n.jsx)(e, {
                params: c,
                searchParams: f
            })
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 92825, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "ClientSegmentRoot", {
            enumerable: !0,
            get: function() {
                return o
            }
        });
        let n = e.r(43476),
            l = e.r(8372),
            a = e.r(71645),
            u = e.r(42903);

        function o({
            Component: e,
            slots: t,
            serverProvidedParams: r
        }) {
            let d;
            if (null !== r) d = r.params;
            else {
                let e = (0, a.use)(l.LayoutRouterContext);
                d = null !== e ? e.parentParams : {}
            }
            let i = (0, u.createClientParams)(d);
            return (0, n.jsx)(e, { ...t,
                params: i
            })
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 68017, (e, t, r) => {
        e.i(47167), Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "HTTPAccessFallbackBoundary", {
            enumerable: !0,
            get: function() {
                return s
            }
        });
        let n = e.r(90809),
            l = e.r(43476),
            a = n._(e.r(71645)),
            u = e.r(90373),
            o = e.r(54394),
            d = e.r(8372);
        class i extends a.default.Component {
            constructor(e) {
                super(e), this.state = {
                    triggeredStatus: void 0,
                    previousPathname: e.pathname
                }
            }
            componentDidCatch() {}
            static getDerivedStateFromError(e) {
                if ((0, o.isHTTPAccessFallbackError)(e)) return {
                    triggeredStatus: (0, o.getAccessFallbackHTTPStatus)(e)
                };
                throw e
            }
            static getDerivedStateFromProps(e, t) {
                return e.pathname !== t.previousPathname && t.triggeredStatus ? {
                    triggeredStatus: void 0,
                    previousPathname: e.pathname
                } : {
                    triggeredStatus: t.triggeredStatus,
                    previousPathname: e.pathname
                }
            }
            render() {
                let {
                    notFound: e,
                    forbidden: t,
                    unauthorized: r,
                    children: n
                } = this.props, {
                    triggeredStatus: a
                } = this.state, u = {
                    [o.HTTPAccessErrorStatus.NOT_FOUND]: e,
                    [o.HTTPAccessErrorStatus.FORBIDDEN]: t,
                    [o.HTTPAccessErrorStatus.UNAUTHORIZED]: r
                };
                if (a) {
                    let d = a === o.HTTPAccessErrorStatus.NOT_FOUND && e,
                        i = a === o.HTTPAccessErrorStatus.FORBIDDEN && t,
                        s = a === o.HTTPAccessErrorStatus.UNAUTHORIZED && r;
                    return d || i || s ? (0, l.jsxs)(l.Fragment, {
                        children: [(0, l.jsx)("meta", {
                            name: "robots",
                            content: "noindex"
                        }), !1, u[a]]
                    }) : n
                }
                return n
            }
        }

        function s({
            notFound: e,
            forbidden: t,
            unauthorized: r,
            children: n
        }) {
            let o = (0, u.useUntrackedPathname)(),
                f = (0, a.useContext)(d.MissingSlotContext);
            return e || t || r ? (0, l.jsx)(i, {
                pathname: o,
                notFound: e,
                forbidden: t,
                unauthorized: r,
                missingSlots: f,
                children: n
            }) : (0, l.jsx)(l.Fragment, {
                children: n
            })
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 77694, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = {
            InstantValidationBoundaryContext: function() {
                return a.InstantValidationBoundaryContext
            },
            PlaceValidationBoundaryBelowThisLevel: function() {
                return a.PlaceValidationBoundaryBelowThisLevel
            },
            RenderValidationBoundaryAtThisLevel: function() {
                return a.RenderValidationBoundaryAtThisLevel
            },
            SlotMarker: function() {
                return a.SlotMarker
            }
        };
        for (var l in n) Object.defineProperty(r, l, {
            enumerable: !0,
            get: n[l]
        });
        let a = e.r(22976);
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 22976, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = {
            InstantValidationBoundaryContext: function() {
                return a
            },
            PlaceValidationBoundaryBelowThisLevel: function() {
                return u
            },
            RenderValidationBoundaryAtThisLevel: function() {
                return o
            },
            SlotMarker: function() {
                return d
            }
        };
        for (var l in n) Object.defineProperty(r, l, {
            enumerable: !0,
            get: n[l]
        });
        let a = null,
            u = null,
            o = null,
            d = null;
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 39756, (e, t, r) => {
        e.i(47167), Object.defineProperty(r, "__esModule", {
            value: !0
        });
        var n = {
            LoadingBoundaryProvider: function() {
                return O
            },
            default: function() {
                return C
            }
        };
        for (var l in n) Object.defineProperty(r, l, {
            enumerable: !0,
            get: n[l]
        });
        let a = e.r(90809),
            u = e.r(43476),
            o = a._(e.r(71645)),
            d = e.r(8372),
            i = e.r(1244),
            s = e.r(72383),
            f = e.r(91915),
            c = e.r(58442),
            p = e.r(68017),
            y = e.r(77694),
            m = e.r(27828),
            b = e.r(28298);
        e.r(74180);
        let h = e.r(61994),
            v = e.r(33906),
            P = e.r(24988);

        function g(e, t, r) {
            let n = e.getClientRects();
            if (0 === n.length) return 0;
            let l = 1 / 0;
            for (let e = 0; e < n.length; e++) {
                let t = n[e];
                t.top < l && (l = t.top)
            }
            return l >= r() && l <= t ? 1 : 2
        }

        function j(e) {
            let t = o.default.useRef(null);
            return (0, o.useLayoutEffect)(() => {
                let {
                    scrollRef: r,
                    renderTree: n
                } = e, l = r.forceScroll ? r.scrollRef : n.data.scrollRef;
                if (null === l || !l.current) return;
                let a = null,
                    u = r.hashFragment;
                if (u) {
                    if (null === (a = "top" === u ? document.body : document.getElementById(u) ?? document.getElementsByName(u)[0] ?? null)) {
                        l.current = !1, r.onlyHashChange = !1, r.hashFragment = null;
                        return
                    }
                } else a = t.current;
                if (null === a) return;
                let o = !1;
                (0, f.disableSmoothScrollDuringRouteTransition)(() => {
                    let e = document.documentElement,
                        t = null,
                        r = null,
                        n = null,
                        d = () => {
                            var r;
                            let l, a;
                            return null === n && (r = t, n = !Number.isFinite(a = Number.parseFloat(l = getComputedStyle(e).scrollPaddingTop)) || a < 0 ? 0 : l.endsWith("px") ? a : l.endsWith("%") ? a / 100 * r : 0), n
                        };
                    (u || (t = e.clientHeight, 0 !== (r = g(a, t, d)))) && ((o = !0, l.current = !1, u) ? a.scrollIntoView() : 1 !== r && (e.scrollTop = 0, 2 === g(a, t, d) && a.scrollIntoView()))
                }, {
                    dontForceLayout: !0,
                    onlyHashChange: r.onlyHashChange
                }), o && (r.onlyHashChange = !1, r.hashFragment = null)
            }, void 0), (0, u.jsx)(o.Fragment, {
                ref: t,
                children: e.children
            })
        }

        function _({
            children: e,
            renderTree: t
        }) {
            let r = (0, o.useContext)(d.GlobalLayoutRouterContext);
            if (!r) throw Error("invariant global layout router not mounted");
            return (0, u.jsx)(j, {
                scrollRef: r.scrollRef,
                renderTree: t,
                children: e
            })
        }

        function x({
            tree: e,
            segmentPath: t,
            debugNameContext: r,
            renderTree: n,
            params: l,
            url: a,
            isActive: s
        }) {
            let f, c = (0, o.useContext)(d.GlobalLayoutRouterContext);
            if ((0, o.useContext)(h.NavigationPromisesContext), !c) throw Error("invariant global layout router not mounted");
            let p = null !== n.data.prefetchRsc ? n.data.prefetchRsc : n.data.rsc,
                y = (0, o.useDeferredValue)(n.data.rsc, p);
            if ((0, P.isDeferredRsc)(y)) {
                let e = (0, o.use)(y);
                null === e && (0, o.use)(i.unresolvedThenable), f = e
            } else null === y && (0, o.use)(i.unresolvedThenable), f = y;
            let m = f;
            return (0, u.jsx)(d.LayoutRouterContext.Provider, {
                value: {
                    parentTree: e,
                    parentRenderTree: n,
                    parentSegmentPath: t,
                    parentParams: l,
                    parentLoadingData: null,
                    debugNameContext: r,
                    url: a,
                    isActive: s
                },
                children: m
            })
        }

        function O({
            loading: e,
            children: t
        }) {
            let r = (0, o.use)(d.LayoutRouterContext);
            return null === r ? t : (0, u.jsx)(d.LayoutRouterContext.Provider, {
                value: {
                    parentTree: r.parentTree,
                    parentRenderTree: r.parentRenderTree,
                    parentSegmentPath: r.parentSegmentPath,
                    parentParams: r.parentParams,
                    parentLoadingData: e,
                    debugNameContext: r.debugNameContext,
                    url: r.url,
                    isActive: r.isActive
                },
                children: t
            })
        }

        function T({
            name: e,
            loading: t,
            children: r
        }) {
            if (null !== t) {
                let n = t[0],
                    l = t[1],
                    a = t[2];
                return (0, u.jsx)(o.Suspense, {
                    name: e,
                    fallback: (0, u.jsxs)(u.Fragment, {
                        children: [l, a, n]
                    }),
                    children: r
                })
            }
            return (0, u.jsx)(u.Fragment, {
                children: r
            })
        }

        function C({
            parallelRouterKey: e,
            error: t,
            errorStyles: r,
            errorScripts: n,
            templateStyles: l,
            templateScripts: a,
            template: f,
            notFound: h,
            forbidden: P,
            unauthorized: g,
            segmentViewBoundaries: j
        }) {
            let O = (0, o.useContext)(d.LayoutRouterContext);
            if (!O) throw Error("invariant expected layout router to be mounted");
            let {
                parentTree: M,
                parentRenderTree: R,
                parentSegmentPath: S,
                parentParams: F,
                parentLoadingData: B,
                url: A,
                isActive: L,
                debugNameContext: E
            } = O, w = M[0], H = null === S ? [e] : S.concat([w, e]), D = M[1][e], N = R.slots ?.get(e);
            (void 0 === D || void 0 === N) && (0, o.use)(i.unresolvedThenable);
            let V = null;
            "u" < typeof window && (V = (0, o.use)(y.InstantValidationBoundaryContext));
            let k = D[0],
                I = (0, m.createSegmentKey)(k),
                K = (0, b.useRouterBFCache)(D, N, I),
                U = [];
            do {
                let e = K.tree,
                    i = K.renderTree,
                    m = K.stateKey,
                    b = e[0],
                    j = F;
                if (Array.isArray(b)) {
                    let e = b[0],
                        t = b[1],
                        r = b[2],
                        n = (0, v.getParamValueFromCacheKey)(t, r);
                    null !== n && (j = { ...F,
                        [e]: n
                    })
                }
                let O = function(e) {
                        if ("/" === e) return "/";
                        if ("string" == typeof e)
                            if ("(__SLOT__)" === e) return;
                            else return e + "/";
                        return e[1] + "/"
                    }(b),
                    C = O ?? E,
                    M = void 0 === O ? void 0 : E,
                    R = (0, u.jsxs)(_, {
                        renderTree: i,
                        children: [(0, u.jsx)(s.ErrorBoundary, {
                            errorComponent: t,
                            errorStyles: r,
                            errorScripts: n,
                            children: (0, u.jsx)(T, {
                                name: M,
                                loading: B,
                                children: (0, u.jsx)(p.HTTPAccessFallbackBoundary, {
                                    notFound: h,
                                    forbidden: P,
                                    unauthorized: g,
                                    children: (0, u.jsxs)(c.RedirectBoundary, {
                                        children: [(0, u.jsx)(x, {
                                            url: A,
                                            tree: e,
                                            params: j,
                                            renderTree: i,
                                            segmentPath: H,
                                            debugNameContext: C,
                                            isActive: L && m === I
                                        }), null]
                                    })
                                })
                            })
                        }), null]
                    });
                "u" < typeof window && "string" == typeof V && (R = (0, u.jsx)(y.RenderValidationBoundaryAtThisLevel, {
                    id: V,
                    children: R
                }));
                let S = (0, u.jsxs)(d.TemplateContext.Provider, {
                    value: R,
                    children: [l, a, f]
                }, m);
                S = (0, u.jsx)(o.Activity, {
                    name: M,
                    mode: m === I ? "visible" : "hidden",
                    children: S
                }, m), U.push(S), K = K.next
            } while (null !== K) return U
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 37457, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "default", {
            enumerable: !0,
            get: function() {
                return o
            }
        });
        let n = e.r(90809),
            l = e.r(43476),
            a = n._(e.r(71645)),
            u = e.r(8372);

        function o() {
            let e = (0, a.useContext)(u.TemplateContext);
            return (0, l.jsx)(l.Fragment, {
                children: e
            })
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 97689, (e, t, r) => {
        e.i(47167), Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "createRenderParamsFromClient", {
            enumerable: !0,
            get: function() {
                return n
            }
        });
        let n = e.r(6831).createRenderParamsFromClient;
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 6831, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "createRenderParamsFromClient", {
            enumerable: !0,
            get: function() {
                return l
            }
        });
        let n = new WeakMap;

        function l(e) {
            let t = n.get(e);
            if (t) return t;
            let r = Promise.resolve(e);
            return r.status = "fulfilled", r.value = e, n.set(e, r), r
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 66996, (e, t, r) => {
        e.i(47167), Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "createRenderSearchParamsFromClient", {
            enumerable: !0,
            get: function() {
                return n
            }
        });
        let n = e.r(93504).createRenderSearchParamsFromClient;
        ("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 93504, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "createRenderSearchParamsFromClient", {
            enumerable: !0,
            get: function() {
                return l
            }
        });
        let n = new WeakMap;

        function l(e) {
            let t = n.get(e);
            if (t) return t;
            let r = Promise.resolve(e);
            return r.status = "fulfilled", r.value = e, n.set(e, r), r
        }("function" == typeof r.default || "object" == typeof r.default && null !== r.default) && void 0 === r.default.__esModule && (Object.defineProperty(r.default, "__esModule", {
            value: !0
        }), Object.assign(r.default, r), t.exports = r.default)
    }, 27201, (e, t, r) => {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "IconMark", {
            enumerable: !0,
            get: function() {
                return l
            }
        });
        let n = e.r(43476),
            l = () => "u" > typeof window ? null : (0, n.jsx)("meta", {
                name: "«nxt-icon»"
            })
    }, 91915, (e, t, r) => {
        function n(e, t = {}) {
            if (t.onlyHashChange) return void e();
            let r = document.documentElement;
            if ("smooth" !== r.dataset.scrollBehavior) return void e();
            let l = r.style.scrollBehavior;
            r.style.scrollBehavior = "auto", t.dontForceLayout || r.getClientRects(), e(), r.style.scrollBehavior = l
        }
        e.i(47167), Object.defineProperty(r, "__esModule", {
            value: !0
        }), Object.defineProperty(r, "disableSmoothScrollDuringRouteTransition", {
            enumerable: !0,
            get: function() {
                return n
            }
        })
    }])
})();