(() => {
    let e;
    var t, r = globalThis.TURBOPACK;
    if (void 0 === r) r = [];
    else if (!Array.isArray(r)) return;
    var n = function() {
            if (null != self.TURBOPACK_ASSET_SUFFIX) return self.TURBOPACK_ASSET_SUFFIX;
            let e = document ?.currentScript ?.getAttribute ?.("src") ?? "",
                t = e.indexOf("?");
            return t >= 0 ? e.slice(t) : ""
        }(),
        o = ((t = o || {})[t.Runtime = 0] = "Runtime", t[t.Parent = 1] = "Parent", t[t.Update = 2] = "Update", t);
    let l = new WeakMap;

    function i(e, t) {
        this.m = e, this.e = t
    }
    let u = i.prototype,
        s = Object.prototype.hasOwnProperty,
        f = "u" > typeof Symbol && Symbol.toStringTag;

    function c(e, t, r) {
        s.call(e, t) || Object.defineProperty(e, t, r)
    }

    function a(e, t) {
        let r = e.get(t);
        return void 0 === r && (r = p(t), e.set(t, r)), r
    }

    function p(e) {
        return {
            exports: {},
            error: void 0,
            id: e,
            namespaceObject: void 0
        }
    }

    function d(e, t, r) {
        c(e, "__esModule", {
            value: !0
        }), f && c(e, f, {
            value: "Module"
        });
        let n = 0;
        for (; n < t.length;) {
            let r = t[n++],
                o = t[n++];
            if ("number" == typeof o)
                if (0 === o) c(e, r, {
                    value: t[n++],
                    enumerable: !0,
                    writable: !1
                });
                else throw Error(`unexpected tag: ${o}`);
            else "function" == typeof t[n] ? c(e, r, {
                get: o,
                set: t[n++],
                enumerable: !0
            }) : c(e, r, {
                get: o,
                enumerable: !0
            })
        }
        r || Object.seal(e)
    }

    function h(e, t, r) {
        let n, o;
        null != t ? o = (n = a(this.c, t)).exports : (n = this.m, o = this.e), n.namespaceObject = o, d(o, e, r)
    }

    function m(e, t, r, n) {
        let o = Reflect.getOwnPropertyDescriptor(r, n);
        if (o) {
            if ("value" in o) return void e.push(t, 0, o.value);
            if (o.get) return void e.push(t, o.get)
        }
        e.push(t, () => r[n])
    }

    function y(e, t) {
        (null != t ? a(this.c, t) : this.m).exports = e
    }
    u.s = h, u.S = function(e, t) {
        let r = [],
            n = 0;
        for (; n < e.length;) {
            let t = e[n++],
                o = n;
            for (; n < e.length && 0 !== e[n];) n++;
            let l = n;
            n++;
            let i = "string" == typeof t || "number" == typeof t ? w.call(this, t) : t;
            if (l - o == 1) {
                let t = e[o].split(",");
                for (let e = 0; e < t.length; e += 2) m(r, t[e], i, t[e + 1])
            } else
                for (let t = o; t < l; t += 2) m(r, e[t], i, e[t + 1])
        }
        h.call(this, r, t)
    }, u.j = function(e, t) {
        let r, n;
        null != t ? n = (r = a(this.c, t)).exports : (r = this.m, n = this.e);
        let o = function(e, t) {
            let r = l.get(e);
            if (!r) {
                l.set(e, r = []);
                let n = e => {
                    if ("default" !== e) {
                        for (let t of r)
                            if (s.call(t, e)) return t
                    }
                };
                e.exports = e.namespaceObject = new Proxy(t, {
                    get(e, t) {
                        if (s.call(e, t) || "default" === t || "__esModule" === t) return Reflect.get(e, t);
                        let r = n(t);
                        return r && Reflect.get(r, t)
                    },
                    set: () => !1,
                    defineProperty: () => !1,
                    deleteProperty: () => !1,
                    has: (e, t) => !!Reflect.has(e, t) || "default" !== t && "__esModule" !== t && void 0 !== n(t),
                    ownKeys(e) {
                        let t = Reflect.ownKeys(e);
                        for (let e of r)
                            for (let r of Reflect.ownKeys(e)) "default" === r || t.includes(r) || t.push(r);
                        return t
                    },
                    getOwnPropertyDescriptor(e, t) {
                        let r = Reflect.getOwnPropertyDescriptor(e, t);
                        if (r || "default" === t || "__esModule" === t) return r;
                        let o = n(t);
                        if (o) return {
                            enumerable: !0,
                            configurable: !0,
                            get: () => Reflect.get(o, t)
                        }
                    }
                })
            }
            return r
        }(r, n);
        "object" == typeof e && null !== e && o.push(e)
    }, u.v = y, u.n = function(e, t) {
        let r;
        (r = null != t ? a(this.c, t) : this.m).exports = r.namespaceObject = e
    };
    let g = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__,
        b = [null, g({}), g([]), g(g)];

    function O(e, t, r) {
        let n = [],
            o = -1;
        for (let t = e;
            ("object" == typeof t || "function" == typeof t) && !b.includes(t); t = g(t))
            for (let r of Object.getOwnPropertyNames(t)) n.push(r, function(e, t) {
                return () => e[t]
            }(e, r)), -1 === o && "default" === r && (o = n.length - 1);
        return r && o >= 0 || (o >= 0 ? n.splice(o, 1, 0, e) : n.push("default", 0, e)), d(t, n), t
    }

    function w(e) {
        let t = B(e, this.m);
        if (t.namespaceObject) return t.namespaceObject;
        let r = t.exports;
        return t.namespaceObject = O(r, "function" == typeof r ? function(...e) {
            return r.apply(this, e)
        } : Object.create(null), r && r.__esModule)
    }

    function v(e) {
        let t = e.indexOf("#"); - 1 !== t && (e = e.substring(0, t));
        let r = e.indexOf("?");
        return -1 !== r && (e = e.substring(0, r)), e
    }
    u.i = w, u.A = function(e) {
        return this.r(e)(w.bind(this))
    }, u.t = "function" == typeof require ? require : function() {
        throw Error("Unexpected use of runtime require")
    }, u.r = function(e) {
        return B(e, this.m).exports
    }, u.f = function(e) {
        function t(t) {
            if (t = v(t), s.call(e, t)) return e[t].module();
            let r = Error(`Cannot find module '${t}'`);
            throw r.code = "MODULE_NOT_FOUND", r
        }
        return t.keys = () => Object.keys(e), t.resolve = t => {
            if (t = v(t), s.call(e, t)) return e[t].id();
            let r = Error(`Cannot find module '${t}'`);
            throw r.code = "MODULE_NOT_FOUND", r
        }, t.import = async e => await t(e), t
    };
    let R = function(e) {
        let t = new URL(e, "x:/"),
            r = {};
        for (let e in t) r[e] = t[e];
        for (let t in r.href = e, r.pathname = e.replace(/[?#].*/, ""), r.origin = r.protocol = "", r.toString = r.toJSON = (...t) => e, r) Object.defineProperty(this, t, {
            enumerable: !0,
            configurable: !0,
            value: r[t]
        })
    };

    function U(e, t) {
        throw Error(`Invariant: ${t(e)}`)
    }
    R.prototype = URL.prototype, u.U = R, u.z = function(e) {
        throw Error("dynamic usage of require is not supported")
    }, u.g = globalThis;
    let _ = i.prototype,
        k = "string" == typeof TURBOPACK_CHUNK_BASE_PATH ? TURBOPACK_CHUNK_BASE_PATH : "/_next/",
        P = new Map;
    u.M = P;
    let $ = new Map,
        C = new Map,
        A = new Map;
    async function j(e, t, r) {
        let n;
        if ("string" == typeof r) return function(e, t, r) {
            return M(e, t, r)
        }(e, t, x(r));
        let o = r.included || [],
            l = o.map(e => !!P.has(e) || $.get(e));
        if (l.length > 0 && l.every(e => e)) return void await Promise.all(l);
        for (let l of (n = M(e, t, x(r.path)), o)) $.has(l) || $.set(l, n);
        await n
    }
    _.l = function(e) {
        return j(o.Parent, this.m.id, e)
    };
    let E = Promise.resolve(void 0),
        S = new WeakMap;

    function M(t, r, n) {
        let l = e.loadChunkCached(t, n),
            i = S.get(l);
        if (void 0 === i) {
            let e = S.set.bind(S, l, E);
            i = l.then(e).catch(e => {
                let l;
                switch (t) {
                    case o.Runtime:
                        l = `as a runtime dependency of chunk ${r}`;
                        break;
                    case o.Parent:
                        l = `from module ${r}`;
                        break;
                    case o.Update:
                        l = "from an HMR update";
                        break;
                    default:
                        U(t, e => `Unknown source type: ${e}`)
                }
                let i = Error(`Failed to load chunk ${n} ${l}${e?`: ${e}`:""}`, e ? {
                    cause: e
                } : void 0);
                throw i.name = "ChunkLoadError", i
            }), S.set(l, i)
        }
        return i
    }
    _.L = function(e) {
        var t, r;
        return t = o.Parent, r = this.m.id, M(t, r, e)
    };
    _.R = function(e) {
        let t = this.r(e);
        return t ?.default ?? t
    }, _.P = function(e) {
        return `/ROOT/${e??""}`
    }, _.F = function(e, t) {
        return `file:///${encodeURIComponent(t??"ROOT")}/${e.split("/").map(encodeURIComponent).join("/")}`
    }, _.q = function(e, t) {
        y.call(this, `${e}${n}`, t)
    };
    let T = /[^A-Za-z0-9\-_.!~*'()/]/;

    function x(e, t = k) {
        let r = T.test(e) ? e.split("/").map(encodeURIComponent).join("/") : e;
        return `${t}${r}${n}`
    }

    function K(e, t) {
        let r, n = e.indexOf("?");
        if (-1 !== n) r = n;
        else {
            let t = e.indexOf("#");
            r = -1 !== t ? t : e.length
        }
        return r >= t.length && e.startsWith(t, r - t.length)
    }
    _.b = k, _.X = n, _.h = x;

    function N(e) {
        return K(e, ".css")
    }
    let L = new Map;
    u.c = L;
    let B = (e, t) => {
        let r = L.get(e);
        if (r) {
            if (r.error) throw r.error;
            return r
        }
        return I(e, o.Parent, t.id)
    };

    function I(e, t, r) {
        let n = P.get(e);
        if ("function" != typeof n) throw Error(function(e, t, r) {
            let n;
            switch (t) {
                case 0:
                    n = `as a runtime entry of chunk ${r}`;
                    break;
                case 1:
                    n = `because it was required from module ${r}`;
                    break;
                case 2:
                    n = "because of an HMR update";
                    break;
                default:
                    U(t, e => `Unknown source type: ${e}`)
            }
            return `Module ${e} was instantiated ${n}, but the module factory is not available.`
        }(e, t, r));
        let o = p(e),
            l = o.exports;
        L.set(e, o);
        let u = new i(o, l);
        try {
            n(u, o, l)
        } catch (e) {
            throw o.error = e, e
        }
        return o.namespaceObject && o.exports !== o.namespaceObject && O(o.exports, o.namespaceObject), o
    }

    function H(t) {
        let r;
        if (!Array.isArray(t)) return e.registerChunk(void 0, t);
        let n = function(e) {
            if ("string" == typeof e) return e;
            if (e) return {
                src: e.getAttribute("src")
            };
            if ("u" > typeof TURBOPACK_NEXT_CHUNK_URLS) return {
                src: TURBOPACK_NEXT_CHUNK_URLS.pop()
            };
            throw Error("chunk path empty but not in a worker")
        }(t[0]);
        return 2 === t.length ? r = t[1] : (r = void 0, ! function e(t, r, n, o) {
            let l = r,
                i = t[l];
            for (Array.isArray(i) && (e(i, 0, n, o), l++); l < t.length;) {
                let e, r = l + 1;
                for (; r < t.length && "function" != typeof t[r];) r++;
                if (r === t.length) throw Error("malformed chunk format, expected a factory function");
                let i = t[r];
                for (let o = l; o < r; o++) {
                    let r = t[o],
                        l = n.get(r);
                    if (l) {
                        e = l;
                        break
                    }
                }
                let u = e ?? i,
                    s = !1;
                for (let e = l; e < r; e++) {
                    let r = t[e];
                    n.has(r) || (s || (u === i && Object.defineProperty(i, "name", {
                        value: "module evaluation"
                    }), s = !0), n.set(r, u), o ?.(r))
                }
                l = r + 1
            }
        }(t, 1, P)), e.registerChunk(n, r)
    }
    let q = new Map;

    function D(e) {
        let t = q.get(e);
        if (!t) {
            let r, n;
            t = {
                resolved: !1,
                loadingStarted: !1,
                retryAttempts: 0,
                promise: new Promise((e, t) => {
                    r = e, n = t
                }),
                resolve: () => {
                    t.resolved = !0, r()
                },
                reject: n
            }, q.set(e, t)
        }
        return t
    }

    function F(e, t, r, n, o) {
        !(null == n || n instanceof DOMException && "NetworkError" === n.name) || r.retryAttempts >= 1 || q.get(t) !== r ? (q.get(t) === r && q.delete(t), r.reject(n)) : (r.retryAttempts++, setTimeout(() => {
            r.resolved || q.get(t) !== r || (o ? o() : (r.loadingStarted = !1, W(e, t)))
        }, 200 + Math.floor(401 * Math.random())))
    }

    function W(e, t) {
        let r = D(t);
        if (r.loadingStarted) return r.promise;
        if (e === o.Runtime) return r.loadingStarted = !0, N(t) && r.resolve(), r.promise;
        if ("function" == typeof importScripts)
            if (N(t));
            else if (K(t, ".js")) {
            self.TURBOPACK_NEXT_CHUNK_URLS.push(t);
            try {
                importScripts(t)
            } catch (n) {
                F(e, t, r, n)
            }
        } else throw Error(`can't infer type of chunk from URL ${t} in worker`);
        else {
            let n = decodeURI(t);
            if (N(t))
                if (document.querySelectorAll(`link[rel=stylesheet][href="${t}"],link[rel=stylesheet][href^="${t}?"],link[rel=stylesheet][href="${n}"],link[rel=stylesheet][href^="${n}?"]`).length > 0) r.resolve();
                else {
                    let n = () => {
                        let o = document.createElement("link");
                        return o.rel = "stylesheet", o.crossOrigin = null, o.href = t, o.onerror = () => {
                            let l = document.createComment("");
                            o.replaceWith(l), F(e, t, r, void 0, () => l.replaceWith(n()))
                        }, o.onload = () => {
                            r.resolve()
                        }, o
                    };
                    document.head.appendChild(n())
                }
            else if (K(t, ".js")) {
                let o = document.querySelectorAll(`script[src="${t}"],script[src^="${t}?"],script[src="${n}"],script[src^="${n}?"]`);
                if (o.length > 0)
                    for (let n of Array.from(o)) n.addEventListener("error", () => {
                        n.remove(), F(e, t, r)
                    }, {
                        once: !0
                    });
                else {
                    let n = document.createElement("script");
                    n.crossOrigin = null, n.src = t, n.onerror = () => {
                        n.remove(), F(e, t, r)
                    }, document.head.appendChild(n)
                }
            } else throw Error(`can't infer type of chunk from URL ${t}`)
        }
        return r.loadingStarted = !0, r.promise
    }
    e = {
        async registerChunk(e, t) {
            let r;
            if (null != e && (r = function(e) {
                    if ("string" == typeof e) return e;
                    let t = decodeURIComponent(e.src.replace(/[?#].*$/, ""));
                    return t.startsWith(k) ? t.slice(k.length) : t
                }(e), D("string" == typeof e ? x(e) : e.src).resolve()), null != t) {
                for (let e of t.otherChunks) D(x("string" == typeof e ? e : e.path));
                if (await Promise.all(t.otherChunks.map(e => {
                        var t;
                        return t = r, j(o.Runtime, t, e)
                    })), t.runtimeModuleIds.length > 0)
                    for (let e of t.runtimeModuleIds) ! function(e, t) {
                        let r = L.get(t);
                        if (r) {
                            if (r.error) throw r.error;
                            return
                        }
                        I(t, o.Runtime, e)
                    }(r, e)
            }
        },
        loadChunkCached: (e, t) => W(e, t)
    }, globalThis.TURBOPACK = {
        push: H
    }, r.forEach(H)
})();